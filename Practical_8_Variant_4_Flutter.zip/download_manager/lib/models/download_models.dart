enum DownloadStatus { idle, running, completed, failed }

enum DownloadOutcome { success, failed, cancelled }

class RemoteFile {
  const RemoteFile(this.id, this.name, this.megabytes, this.kind);
  final String id;
  final String name;
  final double megabytes;
  final String kind;
}

class FileProgress {
  const FileProgress({
    this.status = DownloadStatus.idle,
    this.fraction = 0,
    this.error,
  });
  final DownloadStatus status;
  final double fraction;
  final String? error;
}

class DownloadSnapshot {
  const DownloadSnapshot(this.files);
  final Map<String, FileProgress> files;
  FileProgress progress(String id) => files[id] ?? const FileProgress();
}

class BatchSummary {
  const BatchSummary({
    required this.success,
    required this.failed,
    required this.cancelled,
    required this.elapsed,
  });
  final int success;
  final int failed;
  final int cancelled;
  final Duration elapsed;
}
