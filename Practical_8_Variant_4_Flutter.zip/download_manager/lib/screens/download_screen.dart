import 'dart:async';
import 'package:flutter/material.dart';
import '../models/download_models.dart';
import '../services/download_manager.dart';

class DownloadScreen extends StatefulWidget {
  const DownloadScreen({super.key, this.manager});
  final DownloadManager? manager;
  @override
  State<DownloadScreen> createState() => _DownloadScreenState();
}

class _DownloadScreenState extends State<DownloadScreen> {
  late final DownloadManager _manager;
  late final Stream<DownloadSnapshot> _stream;
  late Future<List<RemoteFile>> _catalog;
  bool _batchRunning = false;
  BatchSummary? _summary;
  int _generation = 0;

  @override
  void initState() {
    super.initState();
    _manager = widget.manager ?? DownloadManager();
    _stream = _manager.stream;
    _catalog = _load();
  }

  Future<List<RemoteFile>> _load() async {
    final generation = ++_generation;
    final files = await _manager.loadFiles();
    if (!mounted || generation != _generation) return files;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && generation == _generation) _manager.retryUpdates();
    });
    return files;
  }

  void _reload() => setState(() {
    _summary = null;
    _catalog = _load();
  });

  Future<void> _downloadAll(List<RemoteFile> files) async {
    if (_batchRunning) return;
    setState(() {
      _batchRunning = true;
      _summary = null;
    });
    final summary = await _manager.downloadAll(files);
    if (!mounted) return;
    setState(() {
      _batchRunning = false;
      _summary = summary;
    });
  }

  @override
  void dispose() {
    _generation++;
    // Cancels every generating timer and progress subscription immediately.
    // StreamBuilder owns and cancels its UI subscription automatically.
    unawaited(_manager.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Завантаження')),
    body: SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 760),
          child: Column(
            children: [
              _settings(),
              Expanded(
                child: FutureBuilder<List<RemoteFile>>(
                  future: _catalog,
                  builder: (context, snapshot) {
                    if (snapshot.connectionState != ConnectionState.done) {
                      return const StatePanel(
                        icon: Icons.cloud_download_outlined,
                        title: 'Отримуємо каталог',
                        detail: 'Готуємо список доступних матеріалів…',
                        loading: true,
                      );
                    }
                    if (snapshot.hasError) {
                      return StatePanel(
                        icon: Icons.cloud_off_outlined,
                        title: 'Каталог недоступний',
                        detail: snapshot.error is TimeoutException
                            ? 'Сервер не відповів за 3 секунди.'
                            : 'Зменште частоту збоїв і спробуйте ще раз.',
                        action: _reload,
                      );
                    }
                    final files = snapshot.data ?? [];
                    if (files.isEmpty) {
                      return StatePanel(
                        icon: Icons.folder_open,
                        title: 'Поки що немає файлів',
                        detail:
                            'Каталог порожній. Вимкніть порожній режим і повторіть запит.',
                        action: _reload,
                      );
                    }
                    return _downloads(files);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );

  Widget _settings() => Padding(
    padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
    child: Card(
      margin: EdgeInsets.zero,
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        leading: const Icon(Icons.tune),
        title: const Text(
          'Умови мережі',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
        ),
        subtitle: Text(
          'Симуляція • частота збоїв ${(_manager.api.failureRate * 100).round()}%',
          style: const TextStyle(fontSize: 12),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final value in [0.0, 0.5, 1.0])
                ChoiceChip(
                  label: Text('${(value * 100).round()}%'),
                  selected: _manager.api.failureRate == value,
                  onSelected: (_) => setState(() {
                    _manager.api.failureRate = value;
                  }),
                ),
            ],
          ),
          SwitchListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: const Text('Порожній каталог'),
            value: _manager.api.emptyCatalog,
            onChanged: (v) => setState(() {
              _manager.api.emptyCatalog = v;
            }),
          ),
          SwitchListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: const Text('Зависання першого файлу'),
            value: _manager.api.stallFirstFile,
            onChanged: (v) => setState(() {
              _manager.api.stallFirstFile = v;
            }),
          ),
          Wrap(
            spacing: 8,
            children: [
              OutlinedButton(
                onPressed: _batchRunning ? null : _reload,
                child: const Text('Оновити каталог'),
              ),
              TextButton(
                onPressed: _manager.simulateStreamError,
                child: const Text('Збій потоку'),
              ),
            ],
          ),
          const Text(
            'Нові умови діють на наступний запит. Оновлення каталогу скасовує активні завантаження.',
            style: TextStyle(fontSize: 11),
          ),
        ],
      ),
    ),
  );

  Widget _downloads(List<RemoteFile> files) => StreamBuilder<DownloadSnapshot>(
    stream: _stream,
    builder: (context, snapshot) {
      if (!snapshot.hasData && !snapshot.hasError) {
        return const StatePanel(
          icon: Icons.sync,
          title: 'Підключаємо прогрес',
          detail: 'Очікуємо першу подію потоку…',
          loading: true,
        );
      }
      final state = snapshot.data ?? _manager.snapshot;
      final completed = files
          .where((f) => state.progress(f.id).status == DownloadStatus.completed)
          .length;
      return Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Ваші матеріали',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${files.length} файлів · готово $completed',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Color(0xff657670),
                        ),
                      ),
                    ],
                  ),
                ),
                FilledButton.icon(
                  onPressed: _batchRunning || completed == files.length
                      ? null
                      : () => unawaited(_downloadAll(files)),
                  icon: Icon(
                    _batchRunning ? Icons.sync : Icons.download,
                    size: 18,
                  ),
                  label: Text(
                    _batchRunning ? 'Триває…' : 'Завантажити всі',
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
          if (snapshot.hasError)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.all(10),
              color: const Color(0xffffe9dd),
              child: Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Збій оновлень. Завантаження не втрачені.',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                  TextButton(
                    onPressed: _manager.retryUpdates,
                    child: const Text('Повторити'),
                  ),
                ],
              ),
            ),
          if (_summary != null) _summaryCard(_summary!),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
              itemCount: files.length,
              itemBuilder: (_, index) =>
                  _fileCard(files[index], state.progress(files[index].id)),
            ),
          ),
        ],
      );
    },
  );

  Widget _summaryCard(BatchSummary summary) => Container(
    key: const Key('batchSummary'),
    margin: const EdgeInsets.fromLTRB(16, 0, 16, 8),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xffe2efe9),
      borderRadius: BorderRadius.circular(14),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Підсумок завантаження',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        const SizedBox(height: 6),
        Text(
          'Успішно: ${summary.success} · Помилки: ${summary.failed}\n'
          'Скасовано: ${summary.cancelled} · Час: ${(summary.elapsed.inMilliseconds / 1000).toStringAsFixed(1)} с',
          style: const TextStyle(fontSize: 12, height: 1.5),
        ),
      ],
    ),
  );

  Widget _fileCard(RemoteFile file, FileProgress progress) {
    final running = progress.status == DownloadStatus.running;
    final done = progress.status == DownloadStatus.completed;
    final failed = progress.status == DownloadStatus.failed;
    final color = failed ? const Color(0xffb24936) : const Color(0xff147d70);
    final label = switch (progress.status) {
      DownloadStatus.idle => 'Готовий до завантаження',
      DownloadStatus.running => 'Завантаження…',
      DownloadStatus.completed => 'Завантажено',
      DownloadStatus.failed => progress.error ?? 'Помилка завантаження',
    };
    return Container(
      key: ValueKey('file-${file.id}'),
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: failed ? const Color(0xffe8b5a8) : const Color(0xffdfe8e3),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 45,
                height: 45,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xffedf3ef),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  file.kind,
                  style: TextStyle(
                    fontSize: 11,
                    color: color,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      file.name,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${file.megabytes.toStringAsFixed(1)} МБ',
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xff708079),
                      ),
                    ),
                  ],
                ),
              ),
              if (done)
                const Icon(Icons.check_circle, color: Color(0xff147d70))
              else
                IconButton(
                  key: ValueKey('${running ? 'cancel' : 'start'}-${file.id}'),
                  tooltip: running
                      ? 'Скасувати'
                      : failed
                      ? 'Повторити'
                      : 'Завантажити',
                  onPressed: running
                      ? () => _manager.cancel(file.id)
                      : () => unawaited(_manager.start(file)),
                  icon: Icon(
                    running
                        ? Icons.close
                        : failed
                        ? Icons.refresh
                        : Icons.download,
                    color: color,
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          LinearProgressIndicator(
            value: progress.fraction,
            minHeight: 5,
            color: color,
            backgroundColor: const Color(0xffedf1ee),
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: TextStyle(fontSize: 11, color: color),
                ),
              ),
              Text(
                '${(progress.fraction * 100).round()}%',
                style: TextStyle(fontSize: 12, color: color),
              ),
            ],
          ),
          if (failed)
            TextButton.icon(
              onPressed: () => unawaited(_manager.start(file)),
              icon: const Icon(Icons.refresh, size: 16),
              label: const Text('Повторити'),
            ),
        ],
      ),
    );
  }
}

class StatePanel extends StatelessWidget {
  const StatePanel({
    super.key,
    required this.icon,
    required this.title,
    required this.detail,
    this.loading = false,
    this.action,
  });
  final IconData icon;
  final String title;
  final String detail;
  final bool loading;
  final VoidCallback? action;
  @override
  Widget build(BuildContext context) => Center(
    child: SingleChildScrollView(
      padding: const EdgeInsets.all(28),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 56, color: const Color(0xff6c9989)),
          const SizedBox(height: 20),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 12),
          Text(
            detail,
            textAlign: TextAlign.center,
            style: const TextStyle(height: 1.5, color: Color(0xff6b7b73)),
          ),
          const SizedBox(height: 24),
          if (loading)
            const SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(),
            ),
          if (action != null)
            FilledButton(onPressed: action, child: const Text('Повторити')),
        ],
      ),
    ),
  );
}
