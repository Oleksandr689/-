import 'package:flutter/material.dart';
import 'screens/download_screen.dart';

void main() => runApp(const DownloadApp());

class DownloadApp extends StatelessWidget {
  const DownloadApp({super.key, this.home});
  final Widget? home;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Завантаження',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      fontFamily: 'DejaVu',
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff147d70)),
      scaffoldBackgroundColor: const Color(0xfff3f6f5),
    ),
    home: home ?? const HomeScreen(),
  );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.cloud_download_outlined,
              size: 76,
              color: Color(0xff147d70),
            ),
            const SizedBox(height: 24),
            Text(
              'Усі матеріали — в одному місці',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 12),
            const Text(
              'Практична 8 • Варіант 4\nСимуляція асинхронних завантажень',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              icon: const Icon(Icons.arrow_forward),
              onPressed: () => Navigator.of(context).push<void>(
                MaterialPageRoute(builder: (_) => const DownloadScreen()),
              ),
              label: const Text('Відкрити менеджер'),
            ),
          ],
        ),
      ),
    ),
  );
}
