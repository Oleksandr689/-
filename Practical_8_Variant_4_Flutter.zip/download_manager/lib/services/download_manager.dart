import 'dart:async';
import '../models/download_models.dart';
import 'fake_download_api.dart';

class DownloadManager {
  DownloadManager({
    FakeDownloadApi? api,
    this.idleTimeout = const Duration(seconds: 2),
    this.catalogTimeout = const Duration(seconds: 3),
  }) : api = api ?? FakeDownloadApi();
  final FakeDownloadApi api;
  final Duration idleTimeout;
  final Duration catalogTimeout;
  final StreamController<DownloadSnapshot> _controller =
      StreamController<DownloadSnapshot>.broadcast();
  final Map<String, FileProgress> _states = {};
  final Map<String, _ActiveDownload> _active = {};
  bool _disposed = false;
  int _generation = 0;
  Stream<DownloadSnapshot> get stream => _controller.stream;
  DownloadSnapshot get snapshot => DownloadSnapshot(Map.unmodifiable(_states));
  int get activeCount => _active.length;
  bool get isDisposed => _disposed;

  Future<List<RemoteFile>> loadFiles() async {
    final generation = ++_generation;
    for (final id in _active.keys.toList()) {
      cancel(id);
    }
    _states.clear();
    _emit();
    final files = await api.fetchFiles().timeout(catalogTimeout);
    if (_disposed || generation != _generation) return files;
    for (final file in files) {
      _states[file.id] = const FileProgress();
    }
    _emit();
    return files;
  }

  Future<DownloadOutcome> start(RemoteFile file) {
    if (_disposed) return Future.value(DownloadOutcome.cancelled);
    final existing = _active[file.id];
    if (existing != null) return existing.result.future;
    if (_states[file.id]?.status == DownloadStatus.completed) {
      return Future.value(DownloadOutcome.success);
    }
    final job = api.createJob(file);
    final active = _ActiveDownload(job);
    _active[file.id] = active;
    _states[file.id] = const FileProgress(status: DownloadStatus.running);
    _emit();
    active.subscription = job.progress
        .timeout(idleTimeout)
        .listen(
          (value) {
            if (_disposed || _active[file.id] != active) return;
            _states[file.id] = FileProgress(
              status: DownloadStatus.running,
              fraction: value,
            );
            _emit();
            if (value >= 1) _finish(file.id, DownloadOutcome.success);
          },
          onError: (Object error, StackTrace stack) {
            _finish(
              file.id,
              DownloadOutcome.failed,
              error is TimeoutException
                  ? 'Немає прогресу протягом ${idleTimeout.inSeconds} с'
                  : 'Перервано з’єднання з сервером',
            );
          },
          onDone: () {
            if (_active[file.id] == active) {
              _finish(
                file.id,
                DownloadOutcome.failed,
                'Потік завершився до отримання файлу',
              );
            }
          },
          cancelOnError: false,
        );
    return active.result.future;
  }

  void _finish(String id, DownloadOutcome outcome, [String? error]) {
    final active = _active.remove(id);
    if (active == null) return;
    // close() stops the generator synchronously, before awaiting close completion.
    unawaited(active.job.close());
    unawaited(active.subscription?.cancel() ?? Future<void>.value());
    switch (outcome) {
      case DownloadOutcome.success:
        _states[id] = const FileProgress(
          status: DownloadStatus.completed,
          fraction: 1,
        );
      case DownloadOutcome.failed:
        _states[id] = FileProgress(
          status: DownloadStatus.failed,
          fraction: _states[id]?.fraction ?? 0,
          error: error,
        );
      case DownloadOutcome.cancelled:
        _states[id] = const FileProgress();
    }
    _emit();
    active.result.complete(outcome);
  }

  void cancel(String id) => _finish(id, DownloadOutcome.cancelled);

  Future<BatchSummary> downloadAll(List<RemoteFile> files) async {
    final stopwatch = Stopwatch()..start();
    // Each task resolves to an outcome, so one error cannot discard other results.
    final results = await Future.wait<DownloadOutcome>([
      for (final file in files)
        if (_states[file.id]?.status != DownloadStatus.completed) start(file),
    ]);
    stopwatch.stop();
    return BatchSummary(
      success: results.where((r) => r == DownloadOutcome.success).length,
      failed: results.where((r) => r == DownloadOutcome.failed).length,
      cancelled: results.where((r) => r == DownloadOutcome.cancelled).length,
      elapsed: stopwatch.elapsed,
    );
  }

  void _emit() {
    if (!_disposed) _controller.add(snapshot);
  }

  void simulateStreamError() {
    if (!_disposed) _controller.addError(StateError('Збій каналу оновлень'));
  }

  void retryUpdates() => _emit();

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _generation++;
    for (final id in _active.keys.toList()) {
      cancel(id);
    }
    await _controller.close();
  }
}

class _ActiveDownload {
  _ActiveDownload(this.job);
  final DownloadJob job;
  final Completer<DownloadOutcome> result = Completer<DownloadOutcome>();
  StreamSubscription<double>? subscription;
}
