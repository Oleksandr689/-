import 'dart:async';
import 'dart:math';
import '../models/download_models.dart';

/// No actual HTTP requests or files. All data is generated in memory.
class FakeDownloadApi {
  FakeDownloadApi({
    this.failureRate = 0,
    Random? random,
    this.catalogDelay = const Duration(milliseconds: 900),
    this.tick = const Duration(milliseconds: 200),
  }) : _random = random ?? Random();
  final Random _random;
  final Duration catalogDelay;
  final Duration tick;
  double failureRate;
  bool emptyCatalog = false;
  bool stallFirstFile = false;

  Future<List<RemoteFile>> fetchFiles() async {
    final fail = _random.nextDouble() < failureRate;
    final empty = emptyCatalog;
    await Future<void>.delayed(catalogDelay);
    if (fail) throw StateError('Каталог тимчасово недоступний');
    if (empty) return [];
    return const [
      RemoteFile('1', 'Навчальний посібник.pdf', 12.4, 'PDF'),
      RemoteFile('2', 'Приклади коду.zip', 28.8, 'ZIP'),
      RemoteFile('3', 'Відеолекція.mp4', 164.0, 'MP4'),
      RemoteFile('4', 'Презентація.pptx', 8.6, 'PPTX'),
      RemoteFile('5', 'Макети інтерфейсу.fig', 42.1, 'FIG'),
      RemoteFile('6', 'Матеріали практики.zip', 19.7, 'ZIP'),
    ];
  }

  DownloadJob createJob(RemoteFile file) => DownloadJob(
    tick: tick,
    totalTicks: 10 + int.parse(file.id) * 3,
    fail: _random.nextDouble() < failureRate,
    stall: stallFirstFile && file.id == '1',
  );
}

/// Owns a single-subscription progress stream and the generating timer.
class DownloadJob {
  DownloadJob({
    required this.tick,
    required this.totalTicks,
    this.fail = false,
    this.stall = false,
  }) {
    _controller = StreamController<double>(
      onListen: _start,
      onCancel: _stopTimer,
    );
  }
  final Duration tick;
  final int totalTicks;
  final bool fail;
  final bool stall;
  late final StreamController<double> _controller;
  Timer? _timer;
  int _step = 0;
  bool _closed = false;
  int get emittedTicks => _step;
  bool get isStopped => _closed && !(_timer?.isActive ?? false);
  Stream<double> get progress => _controller.stream;

  void _start() {
    if (_closed) return;
    _controller.add(0);
    _timer = Timer.periodic(tick, (_) {
      if (_closed || stall) return;
      _step++;
      if (fail && _step == 4) {
        _controller.addError(StateError('З’єднання з сервером перервано'));
        unawaited(close());
        return;
      }
      _controller.add((_step / totalTicks).clamp(0, 1).toDouble());
      if (_step >= totalTicks) unawaited(close());
    });
  }

  void _stopTimer() {
    _timer?.cancel();
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    _stopTimer();
    await _controller.close();
  }
}
