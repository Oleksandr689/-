import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:download_manager/main.dart';
import 'package:download_manager/screens/download_screen.dart';
import 'package:download_manager/services/download_manager.dart';
import 'package:download_manager/services/fake_download_api.dart';

void main() {
  testWidgets('loading, catalog, progress, cancel and widget disposal', (
    tester,
  ) async {
    final manager = DownloadManager();
    await tester.pumpWidget(
      DownloadApp(home: DownloadScreen(manager: manager)),
    );
    expect(find.text('Отримуємо каталог'), findsOneWidget);
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await tester.pump();
    expect(find.text('Ваші матеріали'), findsOneWidget);
    await tester.tap(find.byKey(const ValueKey('start-1')));
    await tester.pump(const Duration(milliseconds: 500));
    expect(manager.activeCount, 1);
    await tester.tap(find.byKey(const ValueKey('cancel-1')));
    await tester.pump();
    expect(manager.activeCount, 0);
    await tester.tap(find.byKey(const ValueKey('start-1')));
    await tester.pump();
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 5));
    expect(manager.isDisposed, isTrue);
    expect(manager.activeCount, 0);
    expect(tester.takeException(), isNull);
  });

  testWidgets('catalog error can be retried as an empty catalog', (
    tester,
  ) async {
    final api = FakeDownloadApi(failureRate: 1);
    final manager = DownloadManager(api: api);
    await tester.pumpWidget(
      DownloadApp(home: DownloadScreen(manager: manager)),
    );
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    expect(find.text('Каталог недоступний'), findsOneWidget);
    api.failureRate = 0;
    api.emptyCatalog = true;
    await tester.tap(find.text('Повторити'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    expect(find.text('Поки що немає файлів'), findsOneWidget);
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets('leaving while catalog future is pending is safe', (
    tester,
  ) async {
    final manager = DownloadManager();
    await tester.pumpWidget(
      DownloadApp(home: DownloadScreen(manager: manager)),
    );
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump(const Duration(seconds: 4));
    expect(manager.isDisposed, isTrue);
    expect(tester.takeException(), isNull);
  });
}
