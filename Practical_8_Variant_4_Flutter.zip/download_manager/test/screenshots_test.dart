// Actual Flutter raster output, not mockups. Run separately to regenerate docs.
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:download_manager/main.dart';
import 'package:download_manager/screens/download_screen.dart';
import 'package:download_manager/services/download_manager.dart';
import 'package:download_manager/services/fake_download_api.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    final regular = FontLoader('DejaVu')
      ..addFont(rootBundle.load('assets/DejaVuSans.ttf'));
    await regular.load();
    // Material icons are bundled by Flutter, explicitly load for test rendering.
    final icons = FontLoader('MaterialIcons')
      ..addFont(rootBundle.load('fonts/MaterialIcons-Regular.otf'));
    await icons.load();
  });

  testWidgets('capture required application states', (tester) async {
    tester.view.physicalSize = const Size(500, 1280);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final boundaryKey = GlobalKey();
    final api = FakeDownloadApi();
    final manager = DownloadManager(api: api);
    await tester.pumpWidget(
      RepaintBoundary(
        key: boundaryKey,
        child: DownloadApp(home: DownloadScreen(manager: manager)),
      ),
    );

    Future<void> capture(String name) async {
      await tester.pump();
      final boundary =
          boundaryKey.currentContext!.findRenderObject()!
              as RenderRepaintBoundary;
      await tester.runAsync(() async {
        final image = await boundary.toImage(pixelRatio: 1);
        final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
        await Directory('docs').create(recursive: true);
        await File('docs/$name.png').writeAsBytes(bytes!.buffer.asUint8List());
        image.dispose();
      });
    }

    await capture('01_loading');
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await tester.pump();
    expect(find.text('Ваші матеріали'), findsOneWidget);
    await capture('04_data');
    await tester.tap(find.text('Завантажити всі'));
    await tester.pump(const Duration(milliseconds: 800));
    await capture('05_realtime');
    await tester.pump(const Duration(milliseconds: 800));
    await capture('06_realtime_later');
    await tester.pump(const Duration(seconds: 5));
    await tester.pump();
    await capture('07_summary');
    // Reload through the same service controls exposed in the UI.
    await tester.tap(find.text('Умови мережі'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
    api.failureRate = 1;
    await tester.tap(find.text('Оновити каталог'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await tester.tap(find.text('Умови мережі'));
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 400));
    expect(find.text('Каталог недоступний'), findsOneWidget);
    await capture('02_error');
    api.failureRate = 0;
    api.emptyCatalog = true;
    await tester.tap(find.text('Повторити'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await capture('03_empty');
    api.emptyCatalog = false;
    await tester.tap(find.text('Повторити'));
    await tester.pump();
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await tester.pump();
    api.stallFirstFile = true;
    await tester.tap(find.byKey(const ValueKey('start-1')));
    await tester.pump(const Duration(seconds: 3));
    await tester.pump();
    await capture('08_timeout');
    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
    expect(tester.takeException(), isNull);
  });
}
