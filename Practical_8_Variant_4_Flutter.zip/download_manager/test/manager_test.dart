import 'dart:async';
import 'package:flutter_test/flutter_test.dart';
import 'package:download_manager/models/download_models.dart';
import 'package:download_manager/services/download_manager.dart';
import 'package:download_manager/services/fake_download_api.dart';

class SelectiveApi extends FakeDownloadApi {
  SelectiveApi()
    : super(catalogDelay: Duration.zero, tick: const Duration(milliseconds: 2));
  @override
  DownloadJob createJob(RemoteFile file) => DownloadJob(
    tick: tick,
    totalTicks: 8 + int.parse(file.id),
    fail: file.id == '2',
  );
}

void main() {
  test('catalog has six files, empty mode and controlled failure', () async {
    final api = FakeDownloadApi(catalogDelay: Duration.zero);
    expect(await api.fetchFiles(), hasLength(6));
    api.emptyCatalog = true;
    expect(await api.fetchFiles(), isEmpty);
    api.failureRate = 1;
    await expectLater(api.fetchFiles(), throwsStateError);
  });

  test(
    'one failed file does not interrupt five successful downloads',
    () async {
      final manager = DownloadManager(api: SelectiveApi());
      final files = await manager.loadFiles();
      final result = await manager.downloadAll(files);
      expect(result.success, 5);
      expect(result.failed, 1);
      expect(result.cancelled, 0);
      expect(result.elapsed.inMicroseconds, greaterThan(0));
      expect(manager.activeCount, 0);
      await manager.dispose();
    },
  );

  test('cancellation really stops generator and resets progress', () async {
    final manager = DownloadManager(
      api: FakeDownloadApi(
        catalogDelay: Duration.zero,
        tick: const Duration(milliseconds: 10),
      ),
    );
    final files = await manager.loadFiles();
    final result = manager.start(files.first);
    await Future<void>.delayed(const Duration(milliseconds: 35));
    manager.cancel(files.first.id);
    expect(await result, DownloadOutcome.cancelled);
    expect(manager.snapshot.progress('1').status, DownloadStatus.idle);
    expect(manager.snapshot.progress('1').fraction, 0);
    await Future<void>.delayed(const Duration(milliseconds: 40));
    expect(manager.snapshot.progress('1').fraction, 0);
    expect(manager.activeCount, 0);
    await manager.dispose();
  });

  test('Stream.timeout fails stalled download and retry can succeed', () async {
    final api = FakeDownloadApi(
      catalogDelay: Duration.zero,
      tick: const Duration(milliseconds: 2),
    )..stallFirstFile = true;
    final manager = DownloadManager(
      api: api,
      idleTimeout: const Duration(milliseconds: 40),
    );
    final files = await manager.loadFiles();
    expect(await manager.start(files.first), DownloadOutcome.failed);
    expect(manager.snapshot.progress('1').error, contains('Немає прогресу'));
    expect(manager.activeCount, 0);
    api.stallFirstFile = false;
    expect(await manager.start(files.first), DownloadOutcome.success);
    expect(manager.snapshot.progress('1').fraction, 1);
    await manager.dispose();
  });

  test('dispose cancels all running tasks and resolves batch future', () async {
    final manager = DownloadManager(
      api: FakeDownloadApi(catalogDelay: Duration.zero),
    );
    final files = await manager.loadFiles();
    final batch = manager.downloadAll(files);
    await manager.dispose();
    final result = await batch;
    expect(result.cancelled, 6);
    expect(manager.activeCount, 0);
    expect(manager.isDisposed, isTrue);
  });

  test('job timer stops after cancelling its source', () async {
    final job = DownloadJob(
      tick: const Duration(milliseconds: 5),
      totalTicks: 100,
    );
    final subscription = job.progress.listen((_) {});
    await Future<void>.delayed(const Duration(milliseconds: 20));
    await subscription.cancel();
    await job.close();
    final emitted = job.emittedTicks;
    await Future<void>.delayed(const Duration(milliseconds: 20));
    expect(job.emittedTicks, emitted);
    expect(job.isStopped, isTrue);
  });

  test('catalog has a timeout', () async {
    final manager = DownloadManager(
      api: FakeDownloadApi(catalogDelay: const Duration(milliseconds: 50)),
      catalogTimeout: const Duration(milliseconds: 10),
    );
    await expectLater(manager.loadFiles(), throwsA(isA<TimeoutException>()));
    await manager.dispose();
    await Future<void>.delayed(const Duration(milliseconds: 60));
  });
}
